# labisi2025
Mise en place d'un pipeline CI/CD avec GitHub Actions et AWS EC2

Saisir votre Nom et Prénom: []

Saisir votre adresse email: []
